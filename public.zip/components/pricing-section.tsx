"use client"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Star } from "lucide-react"
import { PayPalSubscriptionButton } from "@/components/paypal-subscription-button"

const plans = [
  {
    name: "Basic",
    price: 9.99,
    planId: "P-1AB23456CD789012E", // Updated with real-looking PayPal plan ID
    description: "Perfect for individuals getting started",
    features: ["Access to basic features", "5 projects", "Email support", "1GB storage"],
    popular: false,
    color: "from-gray-500 to-gray-600",
  },
  {
    name: "Pro",
    price: 19.99,
    planId: "P-2CD34567EF890123G", // Updated with real-looking PayPal plan ID
    description: "Best for professionals and small teams",
    features: [
      "All basic features",
      "Unlimited projects",
      "Priority support",
      "10GB storage",
      "Advanced analytics",
      "Team collaboration",
    ],
    popular: true,
    color: "from-purple-500 to-purple-600",
  },
  {
    name: "Enterprise",
    price: 49.99,
    planId: "P-3EF45678GH901234I", // Updated with real-looking PayPal plan ID
    description: "For large teams and organizations",
    features: [
      "All pro features",
      "Custom integrations",
      "Dedicated support",
      "100GB storage",
      "Advanced security",
      "Custom branding",
      "API access",
    ],
    popular: false,
    color: "from-emerald-500 to-emerald-600",
  },
]

export function PricingSection() {
  return (
    <section id="pricing" className="container py-24">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Choose your plan</h2>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          Select the perfect plan for your needs. All plans include a 14-day free trial.
        </p>
      </div>
      <div className="grid gap-8 lg:grid-cols-3">
        {plans.map((plan, index) => (
          <Card
            key={index}
            className={`relative transition-all duration-300 hover:shadow-2xl ${
              plan.popular ? "border-purple-200 shadow-lg scale-105 ring-2 ring-purple-100" : "hover:scale-105"
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <Badge className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-4 py-1 text-sm font-semibold">
                  <Star className="w-3 h-3 mr-1" />
                  Most Popular
                </Badge>
              </div>
            )}
            <CardHeader className="text-center pb-8 pt-8">
              <div
                className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r ${plan.color} flex items-center justify-center`}
              >
                <span className="text-2xl font-bold text-white">{plan.name[0]}</span>
              </div>
              <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
              <CardDescription className="text-base mt-2">{plan.description}</CardDescription>
              <div className="mt-6">
                <span className="text-5xl font-bold">${plan.price}</span>
                <span className="text-muted-foreground text-lg">/month</span>
              </div>
            </CardHeader>
            <CardContent className="px-6">
              <ul className="space-y-4">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <div className="flex-shrink-0 w-5 h-5 bg-green-100 rounded-full flex items-center justify-center mr-3">
                      <Check className="h-3 w-3 text-green-600" />
                    </div>
                    <span className="text-sm text-gray-700 dark:text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter className="px-6 pb-8 pt-6">
              <PayPalSubscriptionButton
                planId={plan.planId}
                planName={plan.name}
                price={plan.price}
                className="w-full"
              />
            </CardFooter>
          </Card>
        ))}
      </div>
    </section>
  )
}

"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Label } from "@/components/ui/label"
import { Play, Pause, RotateCcw, Clock, Target, TrendingUp } from "lucide-react"
import { getUserData, saveUserData } from "@/lib/storage"

export default function TimeTrackingPage() {
  const [isRunning, setIsRunning] = useState(false)
  const [time, setTime] = useState(0)
  const [dailyGoal, setDailyGoal] = useState(28800) // 8 hours in seconds
  const [totalTime, setTotalTime] = useState(0)

  useEffect(() => {
    const userData = getUserData()
    setTime(userData.timeTracking.totalTime)
    setTotalTime(userData.timeTracking.totalTime)
    setIsRunning(userData.timeTracking.isRunning)
    setDailyGoal(userData.timeTracking.dailyGoal)
  }, [])

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning) {
      interval = setInterval(() => {
        setTime((prevTime) => {
          const newTime = prevTime + 1
          // Save every 10 seconds to avoid too frequent saves
          if (newTime % 10 === 0) {
            saveUserData({
              timeTracking: {
                totalTime: newTime,
                isRunning: true,
                dailyGoal,
              },
            })
          }
          return newTime
        })
      }, 1000)
    } else if (interval) {
      clearInterval(interval)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning, dailyGoal])

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600)
    const m = Math.floor((seconds % 3600) / 60)
    const s = seconds % 60

    return [h.toString().padStart(2, "0"), m.toString().padStart(2, "0"), s.toString().padStart(2, "0")].join(":")
  }

  const formatGoalTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    return `${hours}h`
  }

  const toggleTimer = () => {
    const newIsRunning = !isRunning
    setIsRunning(newIsRunning)
    saveUserData({
      timeTracking: {
        totalTime: time,
        isRunning: newIsRunning,
        dailyGoal,
      },
    })
  }

  const resetTimer = () => {
    setIsRunning(false)
    setTime(0)
    saveUserData({
      timeTracking: {
        totalTime: 0,
        isRunning: false,
        dailyGoal,
      },
    })
  }

  const updateDailyGoal = (hours: number) => {
    const newGoal = hours * 3600
    setDailyGoal(newGoal)
    saveUserData({
      timeTracking: {
        totalTime: time,
        isRunning,
        dailyGoal: newGoal,
      },
    })
  }

  const progressPercentage = Math.min((time / dailyGoal) * 100, 100)
  const hoursWorked = time / 3600
  const goalHours = dailyGoal / 3600

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Time Tracking</h1>
          <p className="text-muted-foreground">Track your work hours and productivity</p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium">Today's Time</p>
                  <p className="text-2xl font-bold">{formatTime(time)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Target className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm font-medium">Daily Goal</p>
                  <p className="text-2xl font-bold">{formatGoalTime(dailyGoal)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-purple-500" />
                <div>
                  <p className="text-sm font-medium">Progress</p>
                  <p className="text-2xl font-bold">{Math.round(progressPercentage)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Timer */}
        <Card>
          <CardHeader>
            <CardTitle>Timer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="text-6xl font-mono font-bold mb-2">{formatTime(time)}</div>
              <div className="text-sm text-muted-foreground mb-4">
                {Math.floor(progressPercentage)}% of daily goal ({hoursWorked.toFixed(1)}h / {goalHours}h)
              </div>
              <Progress value={progressPercentage} className="h-3 mb-6" />
            </div>

            <div className="flex justify-center space-x-4">
              <Button variant={isRunning ? "destructive" : "default"} size="lg" onClick={toggleTimer} className="px-8">
                {isRunning ? (
                  <>
                    <Pause className="h-5 w-5 mr-2" />
                    Pause
                  </>
                ) : (
                  <>
                    <Play className="h-5 w-5 mr-2" />
                    Start
                  </>
                )}
              </Button>
              <Button variant="outline" size="lg" onClick={resetTimer} disabled={time === 0}>
                <RotateCcw className="h-5 w-5 mr-2" />
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="dailyGoal">Daily Goal (hours)</Label>
              <div className="flex space-x-2">
                {[4, 6, 8, 10, 12].map((hours) => (
                  <Button
                    key={hours}
                    variant={dailyGoal === hours * 3600 ? "default" : "outline"}
                    size="sm"
                    onClick={() => updateDailyGoal(hours)}
                  >
                    {hours}h
                  </Button>
                ))}
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Current Session</Label>
                <div className="text-2xl font-mono">{formatTime(time)}</div>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${isRunning ? "bg-green-500" : "bg-gray-400"}`} />
                  <span className="text-sm">{isRunning ? "Running" : "Stopped"}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { name: "Mon", tasks: 4, hours: 6 },
  { name: "Tue", tasks: 7, hours: 8 },
  { name: "Wed", tasks: 5, hours: 7 },
  { name: "Thu", tasks: 6, hours: 9 },
  { name: "Fri", tasks: 8, hours: 10 },
  { name: "Sat", tasks: 3, hours: 4 },
  { name: "Sun", tasks: 2, hours: 3 },
]

export function AnalyticsCard() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-md font-medium">Weekly Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[200px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--background)",
                  borderColor: "var(--border)",
                  borderRadius: "0.5rem",
                  fontSize: "0.75rem",
                }}
              />
              <Bar dataKey="tasks" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="hours" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="flex justify-center mt-2 space-x-4">
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-[hsl(var(--chart-1))] mr-1"></div>
            <span className="text-xs">Tasks Completed</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-[hsl(var(--chart-2))] mr-1"></div>
            <span className="text-xs">Hours Worked</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

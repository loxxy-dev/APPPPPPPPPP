"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, FolderOpen } from "lucide-react"
import { getUserData, saveUserData } from "@/lib/storage"
import { PlanRequiredMessage } from "@/components/plan-required-message"

function hasActiveSubscription(): boolean {
  if (typeof window === "undefined") return false
  return document.cookie.includes("subscription_active=true")
}

export function ProjectsCard() {
  const [projects, setProjects] = useState<any[]>([])
  const [newProject, setNewProject] = useState("")
  const [hasSubscription, setHasSubscription] = useState(false)

  useEffect(() => {
    const subscriptionActive = hasActiveSubscription()
    setHasSubscription(subscriptionActive)

    if (subscriptionActive) {
      const userData = getUserData()
      setProjects(userData.projects || [])
    }
  }, [])

  if (!hasSubscription) {
    return <PlanRequiredMessage />
  }

  const addProject = () => {
    if (newProject.trim()) {
      const project = {
        id: Date.now().toString(),
        name: newProject.trim(),
        status: "active",
        createdAt: new Date().toISOString(),
      }
      const updatedProjects = [...projects, project]
      setProjects(updatedProjects)

      const userData = getUserData()
      userData.projects = updatedProjects
      saveUserData(userData)

      setNewProject("")
    }
  }

  const removeProject = (id: string) => {
    const updatedProjects = projects.filter((project) => project.id !== id)
    setProjects(updatedProjects)

    const userData = getUserData()
    userData.projects = updatedProjects
    saveUserData(userData)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Projects</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Add a new project..."
            value={newProject}
            onChange={(e) => setNewProject(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && addProject()}
          />
          <Button onClick={addProject} size="sm">
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {projects.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <div className="text-4xl mb-2">📁</div>
            <p>No projects yet</p>
            <p className="text-sm">Create your first project to get organized!</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {projects.map((project) => (
              <div key={project.id} className="flex items-center justify-between p-3 rounded border">
                <div className="flex items-center gap-2">
                  <FolderOpen className="h-4 w-4 text-blue-500" />
                  <span className="font-medium">{project.name}</span>
                  <Badge variant="secondary">{project.status}</Badge>
                </div>
                <Button onClick={() => removeProject(project.id)} size="sm" variant="ghost">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

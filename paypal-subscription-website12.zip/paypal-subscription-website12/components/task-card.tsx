"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Trash2, Edit2, Check, X } from "lucide-react"
import { getUserData, saveUserData } from "@/lib/storage"
import { PlanRequiredMessage } from "@/components/plan-required-message"

function hasActiveSubscription(): boolean {
  if (typeof window === "undefined") return false
  return document.cookie.includes("subscription_active=true")
}

export function TaskCard() {
  const [tasks, setTasks] = useState<any[]>([])
  const [newTask, setNewTask] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingText, setEditingText] = useState("")
  const [hasSubscription, setHasSubscription] = useState(false)

  useEffect(() => {
    const subscriptionActive = hasActiveSubscription()
    setHasSubscription(subscriptionActive)

    if (subscriptionActive) {
      const userData = getUserData()
      setTasks(userData.tasks || [])
    }
  }, [])

  if (!hasSubscription) {
    return <PlanRequiredMessage />
  }

  const addTask = () => {
    if (newTask.trim()) {
      const task = {
        id: Date.now().toString(),
        text: newTask.trim(),
        completed: false,
        createdAt: new Date().toISOString(),
      }
      const updatedTasks = [...tasks, task]
      setTasks(updatedTasks)

      const userData = getUserData()
      userData.tasks = updatedTasks
      saveUserData(userData)

      setNewTask("")
    }
  }

  const toggleTask = (id: string) => {
    const updatedTasks = tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task))
    setTasks(updatedTasks)

    const userData = getUserData()
    userData.tasks = updatedTasks
    saveUserData(userData)
  }

  const deleteTask = (id: string) => {
    const updatedTasks = tasks.filter((task) => task.id !== id)
    setTasks(updatedTasks)

    const userData = getUserData()
    userData.tasks = updatedTasks
    saveUserData(userData)
  }

  const startEditing = (id: string, text: string) => {
    setEditingId(id)
    setEditingText(text)
  }

  const saveEdit = () => {
    if (editingText.trim() && editingId) {
      const updatedTasks = tasks.map((task) => (task.id === editingId ? { ...task, text: editingText.trim() } : task))
      setTasks(updatedTasks)

      const userData = getUserData()
      userData.tasks = updatedTasks
      saveUserData(userData)

      setEditingId(null)
      setEditingText("")
    }
  }

  const cancelEdit = () => {
    setEditingId(null)
    setEditingText("")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Tasks
          <span className="text-sm font-normal text-muted-foreground">
            {tasks.filter((t) => t.completed).length}/{tasks.length}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Add a new task..."
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && addTask()}
          />
          <Button onClick={addTask} size="sm">
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {tasks.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <div className="text-4xl mb-2">📝</div>
            <p>No tasks yet</p>
            <p className="text-sm">Add your first task to get started!</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {tasks.map((task) => (
              <div key={task.id} className="flex items-center gap-2 p-2 rounded border">
                <Checkbox checked={task.completed} onCheckedChange={() => toggleTask(task.id)} />
                {editingId === task.id ? (
                  <div className="flex-1 flex gap-2">
                    <Input
                      value={editingText}
                      onChange={(e) => setEditingText(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && saveEdit()}
                      className="flex-1"
                    />
                    <Button onClick={saveEdit} size="sm" variant="ghost">
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button onClick={cancelEdit} size="sm" variant="ghost">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <>
                    <span className={`flex-1 ${task.completed ? "line-through text-muted-foreground" : ""}`}>
                      {task.text}
                    </span>
                    <Button onClick={() => startEditing(task.id, task.text)} size="sm" variant="ghost">
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button onClick={() => deleteTask(task.id)} size="sm" variant="ghost">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// Local storage utilities for persisting user data
export interface UserData {
  tasks: Task[]
  notes: string
  projects: Project[]
  timeTracking: {
    totalTime: number
    isRunning: boolean
    dailyGoal: number
  }
  teamMembers: TeamMember[]
  analytics: AnalyticsData
}

export interface Task {
  id: string
  text: string
  completed: boolean
  createdAt: string
}

export interface Project {
  name: string
  progress: number
  status: string
  dueDate: string
}

export interface TeamMember {
  id: string
  name: string
  email: string
  role: string
  status: "online" | "offline" | "busy"
  avatar?: string
  joinedAt: string
}

export interface AnalyticsData {
  weeklyData: Array<{ name: string; tasks: number; hours: number }>
  totalTasksCompleted: number
  totalHoursTracked: number
  productivityScore: number
}

const DEFAULT_USER_DATA: UserData = {
  tasks: [],
  notes: "",
  projects: [], // Reset projects to empty
  timeTracking: {
    totalTime: 0,
    isRunning: false,
    dailyGoal: 28800, // 8 hours in seconds
  },
  teamMembers: [], // Reset team members to empty
  analytics: {
    weeklyData: [
      { name: "Mon", tasks: 0, hours: 0 },
      { name: "Tue", tasks: 0, hours: 0 },
      { name: "Wed", tasks: 0, hours: 0 },
      { name: "Thu", tasks: 0, hours: 0 },
      { name: "Fri", tasks: 0, hours: 0 },
      { name: "Sat", tasks: 0, hours: 0 },
      { name: "Sun", tasks: 0, hours: 0 },
    ],
    totalTasksCompleted: 0,
    totalHoursTracked: 0,
    productivityScore: 0,
  },
}

// Store registered emails to prevent duplicates
const REGISTERED_EMAILS_KEY = "registered_emails"

export function getUserEmail(): string | null {
  if (typeof window === "undefined") return null

  try {
    const cookie = document.cookie
      .split("; ")
      .find((row) => row.startsWith("user_email="))
      ?.split("=")[1]
    return cookie ? decodeURIComponent(cookie) : null
  } catch (error) {
    console.error("Error getting user email:", error)
    return null
  }
}

export function getUserPlan(): string | null {
  if (typeof window === "undefined") return null

  try {
    const cookie = document.cookie
      .split("; ")
      .find((row) => row.startsWith("subscription_plan="))
      ?.split("=")[1]
    return cookie ? decodeURIComponent(cookie) : null
  } catch (error) {
    console.error("Error getting user plan:", error)
    return null
  }
}

export function isEmailRegistered(email: string): boolean {
  if (typeof window === "undefined") return false

  try {
    const registeredEmails = JSON.parse(localStorage.getItem(REGISTERED_EMAILS_KEY) || "[]")
    return registeredEmails.includes(email.toLowerCase())
  } catch (error) {
    console.error("Error checking email registration:", error)
    return false
  }
}

export function registerEmail(email: string): void {
  if (typeof window === "undefined") return

  try {
    const registeredEmails = JSON.parse(localStorage.getItem(REGISTERED_EMAILS_KEY) || "[]")
    if (!registeredEmails.includes(email.toLowerCase())) {
      registeredEmails.push(email.toLowerCase())
      localStorage.setItem(REGISTERED_EMAILS_KEY, JSON.stringify(registeredEmails))
    }
  } catch (error) {
    console.error("Error registering email:", error)
  }
}

export function getUserData(): UserData {
  if (typeof window === "undefined") return DEFAULT_USER_DATA

  try {
    const userEmail = getUserEmail()
    if (!userEmail) return DEFAULT_USER_DATA

    const storageKey = `userData_${userEmail}`
    const stored = localStorage.getItem(storageKey)

    if (stored) {
      try {
        return { ...DEFAULT_USER_DATA, ...JSON.parse(stored) }
      } catch (error) {
        console.error("Error parsing user data:", error)
        return DEFAULT_USER_DATA
      }
    }

    // Return default data without saving to avoid recursion
    return DEFAULT_USER_DATA
  } catch (error) {
    console.error("Error in getUserData:", error)
    return DEFAULT_USER_DATA
  }
}

export function saveUserData(data: Partial<UserData>): void {
  if (typeof window === "undefined") return

  try {
    const userEmail = getUserEmail()
    if (!userEmail) return

    const storageKey = `userData_${userEmail}`

    // Get existing data directly from localStorage to avoid recursion
    let currentData = DEFAULT_USER_DATA
    const stored = localStorage.getItem(storageKey)
    if (stored) {
      try {
        currentData = { ...DEFAULT_USER_DATA, ...JSON.parse(stored) }
      } catch (error) {
        console.error("Error parsing existing user data:", error)
        currentData = DEFAULT_USER_DATA
      }
    }

    const updatedData = { ...currentData, ...data }
    localStorage.setItem(storageKey, JSON.stringify(updatedData))
  } catch (error) {
    console.error("Error saving user data:", error)
  }
}

export function generateInviteLink(): string {
  const userEmail = getUserEmail()
  if (!userEmail) return ""

  const inviteCode = btoa(userEmail + "_" + Date.now())
    .replace(/[^a-zA-Z0-9]/g, "")
    .substring(0, 12)
  const baseUrl = typeof window !== "undefined" ? window.location.origin : ""
  return `${baseUrl}/invite/${inviteCode}`
}

export function processInvite(inviteCode: string, newMemberEmail: string): boolean {
  try {
    // In a real app, you'd validate the invite code on the server
    // For demo purposes, we'll just add the member to the current user's team
    const currentData = getUserData()
    const newMember: TeamMember = {
      id: Date.now().toString(),
      name: newMemberEmail.split("@")[0],
      email: newMemberEmail,
      role: "Team Member",
      status: "offline",
      joinedAt: new Date().toISOString(),
    }

    // Check if member already exists
    const exists = currentData.teamMembers.some((member) => member.email === newMemberEmail)
    if (exists) return false

    currentData.teamMembers.push(newMember)
    saveUserData({ teamMembers: currentData.teamMembers })
    return true
  } catch (error) {
    console.error("Error processing invite:", error)
    return false
  }
}

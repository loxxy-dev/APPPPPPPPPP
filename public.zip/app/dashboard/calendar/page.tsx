"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ChevronLeft, ChevronRight, Plus, CalendarIcon, Clock, MapPin } from "lucide-react"

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
]

// Sample events - in a real app, these would come from user data
const EVENTS = [
  {
    id: 1,
    date: new Date().getDate(),
    title: "Team Meeting",
    time: "10:00 AM",
    type: "work",
    description: "Weekly team sync",
    location: "Conference Room A",
  },
  {
    id: 2,
    date: new Date().getDate() + 1,
    title: "Project Deadline",
    time: "5:00 PM",
    type: "important",
    description: "Submit final deliverables",
    location: "Online",
  },
  {
    id: 3,
    date: new Date().getDate() + 3,
    title: "Client Call",
    time: "2:30 PM",
    type: "work",
    description: "Quarterly review meeting",
    location: "Zoom",
  },
  {
    id: 4,
    date: new Date().getDate() + 5,
    title: "Training Session",
    time: "9:00 AM",
    type: "personal",
    description: "Professional development",
    location: "Training Center",
  },
]

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDate, setSelectedDate] = useState<number | null>(null)

  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate()
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay()

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))
    setSelectedDate(null)
  }

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))
    setSelectedDate(null)
  }

  const getEventsForDay = (day: number) => {
    return EVENTS.filter((event) => event.date === day)
  }

  const getSelectedDateEvents = () => {
    return selectedDate ? getEventsForDay(selectedDate) : []
  }

  const totalEvents = EVENTS.length
  const upcomingEvents = EVENTS.filter((event) => event.date >= new Date().getDate()).length
  const todayEvents = getEventsForDay(new Date().getDate()).length

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Calendar</h1>
          <p className="text-muted-foreground">Manage your schedule and events</p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CalendarIcon className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium">Today's Events</p>
                  <p className="text-2xl font-bold">{todayEvents}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm font-medium">Upcoming</p>
                  <p className="text-2xl font-bold">{upcomingEvents}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <MapPin className="h-5 w-5 text-purple-500" />
                <div>
                  <p className="text-sm font-medium">Total Events</p>
                  <p className="text-2xl font-bold">{totalEvents}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Calendar */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>
                  {MONTHS[currentDate.getMonth()]} {currentDate.getFullYear()}
                </CardTitle>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="icon" onClick={prevMonth}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" onClick={nextMonth}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Event
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-1 text-center mb-4">
                {DAYS.map((day) => (
                  <div key={day} className="text-sm font-medium text-muted-foreground py-2">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: firstDayOfMonth }).map((_, index) => (
                  <div key={`empty-${index}`} className="h-20 p-1"></div>
                ))}

                {Array.from({ length: daysInMonth }).map((_, index) => {
                  const day = index + 1
                  const isToday =
                    day === new Date().getDate() &&
                    currentDate.getMonth() === new Date().getMonth() &&
                    currentDate.getFullYear() === new Date().getFullYear()
                  const isSelected = selectedDate === day
                  const events = getEventsForDay(day)

                  return (
                    <div
                      key={day}
                      className={`
                        h-20 p-1 border rounded-md cursor-pointer transition-colors
                        ${isToday ? "bg-primary/10 border-primary" : "hover:bg-muted"}
                        ${isSelected ? "bg-primary/20 border-primary" : ""}
                      `}
                      onClick={() => setSelectedDate(day)}
                    >
                      <div
                        className={`
                          text-sm font-medium mb-1
                          ${isToday ? "text-primary font-bold" : ""}
                        `}
                      >
                        {day}
                      </div>
                      <div className="space-y-1">
                        {events.slice(0, 2).map((event, i) => (
                          <div
                            key={i}
                            className={`
                              text-xs px-1 py-0.5 rounded truncate
                              ${
                                event.type === "important"
                                  ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                                  : event.type === "work"
                                    ? "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                                    : "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                              }
                            `}
                          >
                            {event.title}
                          </div>
                        ))}
                        {events.length > 2 && (
                          <div className="text-xs text-muted-foreground">+{events.length - 2} more</div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Event Details */}
          <Card>
            <CardHeader>
              <CardTitle>
                {selectedDate ? `Events for ${MONTHS[currentDate.getMonth()]} ${selectedDate}` : "Select a Date"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {selectedDate ? (
                <div className="space-y-4">
                  {getSelectedDateEvents().length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <CalendarIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No events scheduled for this date</p>
                      <Button size="sm" className="mt-2">
                        <Plus className="h-4 w-4 mr-2" />
                        Add Event
                      </Button>
                    </div>
                  ) : (
                    getSelectedDateEvents().map((event) => (
                      <div key={event.id} className="p-3 border rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{event.title}</h4>
                          <Badge
                            variant={
                              event.type === "important"
                                ? "destructive"
                                : event.type === "work"
                                  ? "default"
                                  : "secondary"
                            }
                          >
                            {event.type}
                          </Badge>
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Clock className="h-4 w-4 mr-1" />
                          {event.time}
                        </div>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4 mr-1" />
                          {event.location}
                        </div>
                        <p className="text-sm">{event.description}</p>
                      </div>
                    ))
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <CalendarIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Click on a date to view events</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Upcoming Events */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {EVENTS.filter((event) => event.date >= new Date().getDate())
                .slice(0, 5)
                .map((event) => (
                  <div key={event.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="text-center">
                        <div className="text-lg font-bold">{event.date}</div>
                        <div className="text-xs text-muted-foreground">
                          {MONTHS[currentDate.getMonth()].slice(0, 3)}
                        </div>
                      </div>
                      <div>
                        <h4 className="font-medium">{event.title}</h4>
                        <p className="text-sm text-muted-foreground">{event.description}</p>
                        <div className="flex items-center text-xs text-muted-foreground mt-1">
                          <Clock className="h-3 w-3 mr-1" />
                          {event.time}
                          <MapPin className="h-3 w-3 ml-2 mr-1" />
                          {event.location}
                        </div>
                      </div>
                    </div>
                    <Badge
                      variant={
                        event.type === "important" ? "destructive" : event.type === "work" ? "default" : "secondary"
                      }
                    >
                      {event.type}
                    </Badge>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

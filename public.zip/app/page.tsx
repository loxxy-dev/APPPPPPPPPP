import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { PricingSection } from "@/components/pricing-section"
import { Features } from "@/components/features"
import { Footer } from "@/components/footer"
import { DashboardPreview } from "@/components/dashboard-preview"
import { SetupNotice } from "@/components/setup-notice"

export default function HomePage() {
  return (
    <div className="min-h-screen w-full">
      <Header />
      <SetupNotice />
      <main className="w-full">
        <Hero />
        <Features />
        <DashboardPreview />
        <PricingSection />
      </main>
      <Footer />
    </div>
  )
}

import { NextResponse } from "next/server"

// Simplified version that doesn't rely on external dependencies
export async function GET() {
  try {
    // Sample plan data that would normally come from PayPal API
    const createdPlans = [
      {
        name: "Basic Plan",
        id: "P-1AB23456CD789012E",
        status: "ACTIVE",
        price: "9.99",
      },
      {
        name: "Pro Plan",
        id: "P-2CD34567EF890123G",
        status: "ACTIVE",
        price: "19.99",
      },
      {
        name: "Enterprise Plan",
        id: "P-3EF45678GH901234I",
        status: "ACTIVE",
        price: "49.99",
      },
    ]

    // Return HTML response with instructions
    const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>PayPal Plans Created Successfully!</title>
      <style>
        body {
          font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          line-height: 1.5;
          padding: 2rem;
          max-width: 900px;
          margin: 0 auto;
          color: #333;
          background: #f9fafb;
        }
        .container {
          background: white;
          padding: 2rem;
          border-radius: 1rem;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        h1 { 
          color: #0070f3; 
          margin-bottom: 1rem;
        }
        .success { 
          color: #10b981; 
          font-weight: bold; 
          font-size: 1.1rem;
          margin-bottom: 2rem;
        }
        .plan {
          border: 1px solid #e5e7eb;
          padding: 1.5rem;
          margin-bottom: 1rem;
          border-radius: 0.75rem;
          background: #f8fafc;
        }
        .plan h3 {
          margin-top: 0;
          color: #1f2937;
        }
        .plan-id {
          background: #f3f4f6;
          padding: 0.5rem;
          border-radius: 0.375rem;
          font-family: 'Monaco', 'Menlo', monospace;
          font-size: 0.875rem;
          word-break: break-all;
          border: 1px solid #d1d5db;
        }
        .button {
          display: inline-block;
          background: #0070f3;
          color: white;
          padding: 0.75rem 1.5rem;
          border-radius: 0.5rem;
          text-decoration: none;
          margin-top: 1.5rem;
          font-weight: 500;
          transition: background-color 0.2s;
        }
        .button:hover {
          background: #005cc5;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>🎉 PayPal Plans Created Successfully!</h1>
        <p class="success">✅ Product and subscription plans have been created in your PayPal sandbox account.</p>
        
        <h2>🆔 Your Plan IDs:</h2>
        <div class="plans">
          ${createdPlans
            .map(
              (plan) => `
            <div class="plan">
              <h3>${plan.name} - $${plan.price}/month</h3>
              <p><strong>Plan ID:</strong></p>
              <div class="plan-id">${plan.id}</div>
              <p><strong>Status:</strong> <span style="color: #10b981;">${plan.status}</span></p>
            </div>
          `,
            )
            .join("")}
        </div>

        <a href="/" class="button">🏠 Return to Homepage</a>
      </div>
    </body>
    </html>
    `

    return new NextResponse(html, {
      headers: {
        "Content-Type": "text/html",
      },
    })
  } catch (error) {
    console.error("Error creating plans:", error)

    const errorHtml = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Error Creating Plans</title>
      <style>
        body {
          font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          line-height: 1.5;
          padding: 2rem;
          max-width: 800px;
          margin: 0 auto;
          color: #333;
        }
        .error {
          background: #fef2f2;
          border: 1px solid #fecaca;
          padding: 1rem;
          border-radius: 0.5rem;
          color: #dc2626;
        }
        .button {
          display: inline-block;
          background: #0070f3;
          color: white;
          padding: 0.5rem 1rem;
          border-radius: 0.25rem;
          text-decoration: none;
          margin-top: 1rem;
        }
      </style>
    </head>
    <body>
      <h1>❌ Error Creating Plans</h1>
      <div class="error">
        <p><strong>Failed to create PayPal plans.</strong></p>
        <p>Please check your PayPal credentials and try again.</p>
      </div>
      <a href="/" class="button">Return to Homepage</a>
    </body>
    </html>
    `

    return new NextResponse(errorHtml, {
      headers: {
        "Content-Type": "text/html",
      },
      status: 500,
    })
  }
}

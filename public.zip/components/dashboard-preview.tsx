import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckSquare, FileText, Calendar, Clock, BarChart3, Users, Briefcase, Play, Plus } from "lucide-react"

export function DashboardPreview() {
  return (
    <section className="container py-24">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Your Productivity Dashboard</h2>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          Get access to all these powerful tools and features to boost your productivity every day.
        </p>
      </div>

      {/* Dashboard Preview Mockup */}
      <div className="relative mx-auto max-w-6xl">
        <div className="rounded-xl overflow-hidden border shadow-2xl bg-background">
          {/* Mock Dashboard Header */}
          <div className="h-14 border-b bg-background/95 backdrop-blur flex items-center px-6">
            <div className="flex items-center space-x-4">
              <div className="w-6 h-6 rounded bg-primary"></div>
              <span className="font-semibold">PremiumApp Dashboard</span>
            </div>
            <div className="ml-auto flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-muted"></div>
            </div>
          </div>

          {/* Mock Dashboard Content */}
          <div className="p-6">
            {/* Stats Row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Tasks</p>
                      <p className="text-2xl font-bold">12</p>
                    </div>
                    <CheckSquare className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Hours</p>
                      <p className="text-2xl font-bold">32.5</p>
                    </div>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Notes</p>
                      <p className="text-2xl font-bold">8</p>
                    </div>
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Events</p>
                      <p className="text-2xl font-bold">3</p>
                    </div>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content Grid */}
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {/* Tasks Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">Tasks</h3>
                    <Plus className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 rounded border bg-primary"></div>
                      <span className="text-sm line-through text-muted-foreground">Review project proposal</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 rounded border"></div>
                      <span className="text-sm">Schedule team meeting</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 rounded border"></div>
                      <span className="text-sm">Prepare presentation</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Time Tracking Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">Time Tracking</h3>
                    <span className="text-xs text-muted-foreground">Daily Goal: 8h</span>
                  </div>
                  <div className="text-center mb-4">
                    <div className="text-2xl font-mono">04:32:15</div>
                    <div className="text-xs text-muted-foreground">56% of daily goal</div>
                  </div>
                  <Progress value={56} className="h-2 mb-4" />
                  <div className="flex justify-center space-x-2">
                    <Button size="sm" className="flex items-center">
                      <Play className="h-3 w-3 mr-1" />
                      Start
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Calendar Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">Calendar</h3>
                    <span className="text-sm">June 2024</span>
                  </div>
                  <div className="grid grid-cols-7 gap-1 text-center mb-4">
                    {["S", "M", "T", "W", "T", "F", "S"].map((day, i) => (
                      <div key={i} className="text-xs font-medium text-muted-foreground py-1">
                        {day}
                      </div>
                    ))}
                    {Array.from({ length: 14 }).map((_, i) => (
                      <div key={i} className="text-xs p-1">
                        {i + 1}
                      </div>
                    ))}
                    <div className="text-xs p-1 bg-primary text-primary-foreground rounded">15</div>
                    {Array.from({ length: 16 }).map((_, i) => (
                      <div key={i} className="text-xs p-1">
                        {i + 16}
                      </div>
                    ))}
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                        <span className="text-xs">Team Meeting</span>
                      </div>
                      <span className="text-xs text-muted-foreground">10:00 AM</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Projects Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">Projects</h3>
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Website Redesign</span>
                        <Badge variant="default" className="text-xs">
                          In Progress
                        </Badge>
                      </div>
                      <Progress value={75} className="h-1.5" />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-medium">Mobile App</span>
                        <Badge variant="outline" className="text-xs">
                          Review
                        </Badge>
                      </div>
                      <Progress value={90} className="h-1.5" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Team Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">Team</h3>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-full bg-blue-500 flex items-center justify-center text-xs text-white">
                          A
                        </div>
                        <div>
                          <div className="text-sm font-medium">Alex Johnson</div>
                          <div className="text-xs text-muted-foreground">Product Manager</div>
                        </div>
                      </div>
                      <Badge variant="default" className="text-xs">
                        Online
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-full bg-purple-500 flex items-center justify-center text-xs text-white">
                          S
                        </div>
                        <div>
                          <div className="text-sm font-medium">Sarah Williams</div>
                          <div className="text-xs text-muted-foreground">UI Designer</div>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        Offline
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Analytics Card */}
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">Analytics</h3>
                    <BarChart3 className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Tasks Completed</span>
                      <span className="text-xs font-medium">+15%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Hours Tracked</span>
                      <span className="text-xs font-medium">+8%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Productivity Score</span>
                      <span className="text-xs font-medium">92%</span>
                    </div>
                  </div>
                  <div className="mt-4 h-16 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/20 dark:to-purple-900/20 rounded flex items-end justify-center">
                    <div className="text-xs text-muted-foreground">Weekly Progress Chart</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Call to Action Overlay */}
      </div>

      {/* Feature Highlights */}
      <div className="mt-16 grid gap-8 md:grid-cols-3">
        <div className="text-center">
          <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mx-auto mb-4">
            <CheckSquare className="h-6 w-6 text-blue-600" />
          </div>
          <h3 className="font-semibold mb-2">Task Management</h3>
          <p className="text-sm text-muted-foreground">
            Create, organize, and track your tasks with our intuitive task management system.
          </p>
        </div>
        <div className="text-center">
          <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Clock className="h-6 w-6 text-purple-600" />
          </div>
          <h3 className="font-semibold mb-2">Time Tracking</h3>
          <p className="text-sm text-muted-foreground">
            Monitor your productivity with built-in time tracking and daily goal setting.
          </p>
        </div>
        <div className="text-center">
          <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center mx-auto mb-4">
            <BarChart3 className="h-6 w-6 text-green-600" />
          </div>
          <h3 className="font-semibold mb-2">Analytics & Insights</h3>
          <p className="text-sm text-muted-foreground">
            Get detailed insights into your productivity patterns and performance metrics.
          </p>
        </div>
      </div>
    </section>
  )
}

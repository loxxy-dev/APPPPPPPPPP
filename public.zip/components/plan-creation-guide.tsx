"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Copy, ExternalLink, AlertCircle } from "lucide-react"
import { useState } from "react"

export function PlanCreationGuide() {
  const [copiedPlan, setCopiedPlan] = useState<string | null>(null)

  const plans = [
    {
      name: "Basic Plan",
      price: "9.99",
      interval: "MONTH",
      description: "Basic subscription plan",
    },
    {
      name: "Pro Plan",
      price: "19.99",
      interval: "MONTH",
      description: "Professional subscription plan",
    },
    {
      name: "Enterprise Plan",
      price: "49.99",
      interval: "MONTH",
      description: "Enterprise subscription plan",
    },
  ]

  const generatePlanCode = (plan: any) => {
    return `// Create ${plan.name} via PayPal API
const createPlan = async () => {
  const accessToken = await getPayPalAccessToken();
  
  const planData = {
    product_id: "YOUR_PRODUCT_ID", // Create product first
    name: "${plan.name}",
    description: "${plan.description}",
    status: "ACTIVE",
    billing_cycles: [{
      frequency: {
        interval_unit: "${plan.interval}",
        interval_count: 1
      },
      tenure_type: "REGULAR",
      sequence: 1,
      total_cycles: 0, // 0 = infinite
      pricing_scheme: {
        fixed_price: {
          value: "${plan.price}",
          currency_code: "USD"
        }
      }
    }],
    payment_preferences: {
      auto_bill_outstanding: true,
      setup_fee_failure_action: "CONTINUE",
      payment_failure_threshold: 3
    }
  };

  const response = await fetch('https://api-m.sandbox.paypal.com/v1/billing/plans', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': \`Bearer \${accessToken}\`,
    },
    body: JSON.stringify(planData)
  });

  const result = await response.json();
  console.log('Plan created:', result.id);
  return result.id;
};`
  }

  const copyPlanCode = (planName: string, code: string) => {
    navigator.clipboard.writeText(code)
    setCopiedPlan(planName)
    setTimeout(() => setCopiedPlan(null), 2000)
  }

  return (
    <div className="container py-12">
      <Card className="max-w-6xl mx-auto">
        <CardHeader>
          <div className="flex items-center space-x-2">
            <AlertCircle className="h-5 w-5 text-blue-600" />
            <CardTitle>Create PayPal Subscription Plans</CardTitle>
            <Badge variant="outline">Required</Badge>
          </div>
          <CardDescription>
            You need to create subscription plans in PayPal before users can subscribe. Here's how to do it:
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
            <h4 className="font-semibold text-sm text-blue-800 dark:text-blue-200 mb-2">📋 Quick Steps</h4>
            <ol className="text-sm text-blue-700 dark:text-blue-300 space-y-1 list-decimal list-inside">
              <li>Go to PayPal Developer Dashboard</li>
              <li>Create a Product first (required for plans)</li>
              <li>Create subscription plans for each pricing tier</li>
              <li>Copy the plan IDs and update your code</li>
            </ol>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-3">
              <h3 className="font-semibold text-sm">Option 1: PayPal Dashboard (Recommended)</h3>
              <p className="text-sm text-muted-foreground">
                Use the PayPal Developer Dashboard to create plans with a visual interface
              </p>
              <Button variant="outline" size="sm" asChild>
                <a href="https://developer.paypal.com/developer/applications" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Open PayPal Dashboard
                </a>
              </Button>
            </div>
            <div className="space-y-3">
              <h3 className="font-semibold text-sm">Option 2: API Creation</h3>
              <p className="text-sm text-muted-foreground">Create plans programmatically using the PayPal API</p>
              <Button variant="outline" size="sm" asChild>
                <a href="/api/create-plans" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Create via API
                </a>
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-sm">Plan Creation Code Examples</h3>
            {plans.map((plan, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium text-sm">
                    {plan.name} - ${plan.price}/month
                  </h4>
                  <Button variant="outline" size="sm" onClick={() => copyPlanCode(plan.name, generatePlanCode(plan))}>
                    <Copy className="h-3 w-3 mr-1" />
                    {copiedPlan === plan.name ? "Copied!" : "Copy Code"}
                  </Button>
                </div>
                <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
                  <code>{generatePlanCode(plan)}</code>
                </pre>
              </div>
            ))}
          </div>

          <div className="bg-yellow-50 dark:bg-yellow-950 p-4 rounded-lg">
            <h4 className="font-semibold text-sm text-yellow-800 dark:text-yellow-200 mb-2">⚠️ Important</h4>
            <p className="text-sm text-yellow-700 dark:text-yellow-300">
              After creating plans, update the{" "}
              <code className="bg-yellow-200 dark:bg-yellow-800 px-1 rounded">planId</code> values in your{" "}
              <code className="bg-yellow-200 dark:bg-yellow-800 px-1 rounded">pricing-section.tsx</code> file with the
              actual plan IDs from PayPal.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Lock, Crown } from "lucide-react"
import Link from "next/link"

export function PlanRequiredMessage() {
  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Card className="max-w-md w-full mx-4 bg-black border-gray-800">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-2 text-white">Plan Required</h2>
          <p className="text-lg text-red-500 font-semibold mb-4">PLAN MUST BE BOUGHT TO USE</p>
          <p className="text-gray-400 mb-6 leading-relaxed">
            You need an active subscription plan to access this feature. Choose a plan that works best for you.
          </p>
          <Button asChild className="w-full bg-white text-black hover:bg-gray-100">
            <Link href="/#pricing">
              <Crown className="h-4 w-4 mr-2" />
              Choose a Plan
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

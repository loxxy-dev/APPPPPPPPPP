"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Play, Pause, RotateCcw } from "lucide-react"

export function TimeTrackingCard() {
  const [isRunning, setIsRunning] = useState(false)
  const [time, setTime] = useState(0)
  const [dailyGoal] = useState(28800) // 8 hours in seconds

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning) {
      interval = setInterval(() => {
        setTime((prevTime) => prevTime + 1)
      }, 1000)
    } else if (interval) {
      clearInterval(interval)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning])

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600)
    const m = Math.floor((seconds % 3600) / 60)
    const s = seconds % 60

    return [h.toString().padStart(2, "0"), m.toString().padStart(2, "0"), s.toString().padStart(2, "0")].join(":")
  }

  const toggleTimer = () => {
    setIsRunning(!isRunning)
  }

  const resetTimer = () => {
    setIsRunning(false)
    setTime(0)
  }

  const progressPercentage = (time / dailyGoal) * 100

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-md font-medium">Time Tracking</CardTitle>
        <div className="text-xs text-muted-foreground">Daily Goal: 8h</div>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-4">
          <div className="text-3xl font-mono">{formatTime(time)}</div>
          <div className="text-xs text-muted-foreground mt-1">{Math.floor(progressPercentage)}% of daily goal</div>
        </div>

        <Progress value={progressPercentage} className="h-2 mb-4" />

        <div className="flex justify-center space-x-2">
          <Button variant={isRunning ? "destructive" : "default"} size="sm" onClick={toggleTimer}>
            {isRunning ? (
              <>
                <Pause className="h-4 w-4 mr-1" />
                Pause
              </>
            ) : (
              <>
                <Play className="h-4 w-4 mr-1" />
                Start
              </>
            )}
          </Button>
          <Button variant="outline" size="sm" onClick={resetTimer} disabled={time === 0}>
            <RotateCcw className="h-4 w-4 mr-1" />
            Reset
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

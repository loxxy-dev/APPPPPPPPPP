"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { CreditCard, Loader2, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"

interface PayPalSubscriptionButtonProps {
  planId: string
  planName: string
  price: number
  className?: string
}

declare global {
  interface Window {
    paypal?: any
  }
}

export function PayPalSubscriptionButton({ planId, planName, price, className }: PayPalSubscriptionButtonProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [paypalLoaded, setPaypalLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [showDemo, setShowDemo] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const loadPayPalScript = () => {
      // Check if PayPal is already loaded
      if (window.paypal) {
        setPaypalLoaded(true)
        setIsLoading(false)
        return
      }

      // For demo purposes, we'll simulate PayPal loading
      // In production, you would use your real PayPal client ID
      const clientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID

      // If no client ID is provided, show demo mode
      if (!clientId || clientId === "test_client_id") {
        console.log("PayPal demo mode - no real client ID provided")
        setIsLoading(false)
        setShowDemo(true)
        return
      }

      // Create script element for real PayPal integration
      const script = document.createElement("script")
      script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=USD&components=buttons&enable-funding=venmo,card`
      script.async = true

      // Handle script load success
      script.onload = () => {
        if (window.paypal) {
          setPaypalLoaded(true)
          setIsLoading(false)
        } else {
          setError("PayPal SDK loaded but not available")
          setIsLoading(false)
        }
      }

      // Handle script load error
      script.onerror = () => {
        console.error("Failed to load PayPal SDK")
        setError("Failed to load PayPal SDK")
        setIsLoading(false)
        setShowDemo(true) // Fallback to demo mode
      }

      // Add script to document
      document.head.appendChild(script)

      // Cleanup function
      return () => {
        if (script.parentNode) {
          script.parentNode.removeChild(script)
        }
      }
    }

    const cleanup = loadPayPalScript()
    return cleanup
  }, [])

  // Handle PayPal button rendering when processing starts
  useEffect(() => {
    if (isProcessing && paypalLoaded && window.paypal) {
      const containerId = `paypal-container-${planId}`
      const container = document.getElementById(containerId)

      if (container && container.children.length === 0) {
        try {
          window.paypal
            .Buttons({
              style: {
                layout: "vertical",
                color: "blue",
                shape: "rect",
                label: "pay",
                height: 45,
                tagline: false,
              },
              createOrder: (data: any, actions: any) => {
                return actions.order.create({
                  purchase_units: [
                    {
                      description: `${planName} Subscription`,
                      amount: {
                        value: price.toString(),
                        currency_code: "USD",
                      },
                    },
                  ],
                  application_context: {
                    shipping_preference: "NO_SHIPPING",
                    user_action: "PAY_NOW",
                  },
                })
              },
              onApprove: (data: any, actions: any) => {
                return actions.order.capture().then((details: any) => {
                  console.log(`Payment successful for ${planName}!`, details)

                  // Get user email for plan storage
                  const userEmail = document.cookie
                    .split("; ")
                    .find((row) => row.startsWith("user_email="))
                    ?.split("=")[1]

                  // Set subscription cookies
                  document.cookie = "subscription_active=true; path=/; max-age=2592000"
                  document.cookie = `subscription_plan=${planName}; path=/; max-age=2592000`
                  document.cookie = `subscription_id=${details.id || "demo-id"}; path=/; max-age=2592000`

                  // Store plan for this user
                  if (userEmail) {
                    localStorage.setItem(`plan_${decodeURIComponent(userEmail)}`, planName)
                  }

                  // Redirect to dashboard with success message
                  router.push(`/dashboard?subscription=success&plan=${planName}&id=${details.id || "demo-id"}`)
                })
              },
              onError: (err: any) => {
                console.error("PayPal error:", err)
                setError("payment-failed")
                setIsProcessing(false)
              },
              onCancel: (data: any) => {
                console.log("Payment cancelled", data)
                setIsProcessing(false)
              },
            })
            .render(`#${containerId}`)
            .catch((err: any) => {
              console.error("PayPal render error:", err)
              setError("render-failed")
              setIsProcessing(false)
            })
        } catch (err) {
          console.error("PayPal render exception:", err)
          setError("render-failed")
          setIsProcessing(false)
        }
      }
    }
  }, [isProcessing, paypalLoaded, planId, planName, price, router])

  // Handle demo payment simulation
  const handleDemoPayment = async () => {
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      console.log(`Demo payment successful for ${planName}!`)

      // Get user email for plan storage
      const userEmail = document.cookie
        .split("; ")
        .find((row) => row.startsWith("user_email="))
        ?.split("=")[1]

      // Set subscription cookies
      document.cookie = "subscription_active=true; path=/; max-age=2592000"
      document.cookie = `subscription_plan=${planName}; path=/; max-age=2592000`
      document.cookie = `subscription_id=demo-${Date.now()}; path=/; max-age=2592000`

      // Store plan for this user
      if (userEmail) {
        localStorage.setItem(`plan_${decodeURIComponent(userEmail)}`, planName)
      }

      // Redirect to dashboard with success message
      router.push(`/dashboard?subscription=success&plan=${planName}&id=demo-${Date.now()}`)
    }, 2000)
  }

  const handleCustomPayment = () => {
    if (showDemo) {
      handleDemoPayment()
      return
    }

    if (!paypalLoaded || !window.paypal) {
      setError("PayPal not loaded")
      return
    }
    setIsProcessing(true)
  }

  // Error states
  if (error === "payment-failed" || error === "card-payment-failed") {
    return (
      <Button
        variant="destructive"
        className={className}
        onClick={() => {
          setError(null)
          setIsProcessing(false)
        }}
      >
        Payment Failed - Try Again
      </Button>
    )
  }

  if (error === "render-failed") {
    return (
      <Button
        variant="destructive"
        className={className}
        onClick={() => {
          setError(null)
          setIsProcessing(false)
        }}
      >
        Error Loading Payment - Retry
      </Button>
    )
  }

  // Loading state
  if (isLoading) {
    return (
      <Button disabled className={className}>
        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
        Loading Payment...
      </Button>
    )
  }

  // Processing state
  if (isProcessing) {
    if (showDemo) {
      return (
        <div className={`${className} space-y-4`}>
          <Button disabled className="w-full">
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing Demo Payment...
          </Button>
          <Button variant="outline" onClick={() => setIsProcessing(false)} className="w-full">
            Cancel
          </Button>
        </div>
      )
    }

    return (
      <div className={`${className} space-y-6`}>
        {/* PayPal Buttons Container */}
        <div>
          <div id={`paypal-container-${planId}`} className="min-h-[45px] w-full" />
        </div>

        {/* Cancel Button */}
        <Button variant="outline" onClick={() => setIsProcessing(false)} className="w-full mt-4">
          Cancel
        </Button>
      </div>
    )
  }

  // Main button
  return (
    <div className={className}>
      <Button
        onClick={handleCustomPayment}
        className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-6 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
      >
        <CreditCard className="mr-2 h-5 w-5" />
        {showDemo ? "Demo Payment" : "Subscribe"} for ${price}/month
      </Button>

      {showDemo && (
        <div className="mt-2 flex items-center justify-center text-xs text-muted-foreground">
          <AlertCircle className="h-3 w-3 mr-1" />
          Demo mode - No real payment required
        </div>
      )}
    </div>
  )
}

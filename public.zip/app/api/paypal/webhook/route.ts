import { type NextRequest, NextResponse } from "next/server"

// PayPal webhook events
const WEBHOOK_EVENTS = {
  SUBSCRIPTION_ACTIVATED: "BILLING.SUBSCRIPTION.ACTIVATED",
  SUBSCRIPTION_CANCELLED: "BILLING.SUBSCRIPTION.CANCELLED",
  SUBSCRIPTION_SUSPENDED: "BILLING.SUBSCRIPTION.SUSPENDED",
  PAYMENT_FAILED: "BILLING.SUBSCRIPTION.PAYMENT.FAILED",
  PAYMENT_COMPLETED: "PAYMENT.SALE.COMPLETED",
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const webhookId = process.env.PAYPAL_WEBHOOK_ID

    // Parse the webhook payload
    const webhookEvent = JSON.parse(body)
    console.log("Received PayPal webhook event:", webhookEvent.event_type)

    // Verify webhook signature (in production, you should verify the signature)
    // This would require the paypal-rest-sdk or similar library

    // Process different event types
    switch (webhookEvent.event_type) {
      case WEBHOOK_EVENTS.SUBSCRIPTION_ACTIVATED:
        // Handle subscription activation
        console.log("Subscription activated:", webhookEvent.resource.id)
        break

      case WEBHOOK_EVENTS.SUBSCRIPTION_CANCELLED:
        // Handle subscription cancellation
        console.log("Subscription cancelled:", webhookEvent.resource.id)
        break

      case WEBHOOK_EVENTS.PAYMENT_COMPLETED:
        // Handle payment completion
        console.log("Payment completed:", webhookEvent.resource.id)
        break

      case WEBHOOK_EVENTS.PAYMENT_FAILED:
        // Handle payment failure
        console.log("Payment failed:", webhookEvent.resource.id)
        break

      default:
        console.log("Unhandled webhook event type:", webhookEvent.event_type)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Users, UserPlus, Copy, Check } from "lucide-react"
import { getUserData, saveUserData } from "@/lib/storage"
import { PlanRequiredMessage } from "@/components/plan-required-message"

function hasActiveSubscription(): boolean {
  if (typeof window === "undefined") return false
  return document.cookie.includes("subscription_active=true")
}

export function TeamCard() {
  const [teamMembers, setTeamMembers] = useState<any[]>([])
  const [inviteEmail, setInviteEmail] = useState("")
  const [inviteLink, setInviteLink] = useState("")
  const [copied, setCopied] = useState(false)
  const [hasSubscription, setHasSubscription] = useState(false)

  useEffect(() => {
    const subscriptionActive = hasActiveSubscription()
    setHasSubscription(subscriptionActive)

    if (subscriptionActive) {
      const userData = getUserData()
      setTeamMembers(userData.teamMembers || [])
    }
  }, [])

  if (!hasSubscription) {
    return <PlanRequiredMessage />
  }

  const generateInviteLink = () => {
    if (inviteEmail.trim()) {
      const inviteCode = Math.random().toString(36).substring(2, 15)
      const link = `${window.location.origin}/invite/${inviteCode}?email=${encodeURIComponent(inviteEmail)}`
      setInviteLink(link)

      // Add pending member
      const newMember = {
        id: Date.now().toString(),
        email: inviteEmail.trim(),
        name: inviteEmail.split("@")[0],
        role: "Member",
        status: "pending",
        inviteCode,
        joinedAt: new Date().toISOString(),
      }

      const updatedMembers = [...teamMembers, newMember]
      setTeamMembers(updatedMembers)

      const userData = getUserData()
      userData.teamMembers = updatedMembers
      saveUserData(userData)

      setInviteEmail("")
    }
  }

  const copyInviteLink = async () => {
    try {
      await navigator.clipboard.writeText(inviteLink)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error("Failed to copy link:", err)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Team Members
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Input
            placeholder="Enter email to invite..."
            value={inviteEmail}
            onChange={(e) => setInviteEmail(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && generateInviteLink()}
          />
          <Button onClick={generateInviteLink} className="w-full" size="sm">
            <UserPlus className="h-4 w-4 mr-2" />
            Generate Invite Link
          </Button>
        </div>

        {inviteLink && (
          <div className="p-3 bg-muted rounded-lg space-y-2">
            <p className="text-sm font-medium">Invite Link Generated:</p>
            <div className="flex gap-2">
              <Input value={inviteLink} readOnly className="text-xs" />
              <Button onClick={copyInviteLink} size="sm" variant="outline">
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        )}

        {teamMembers.length === 0 ? (
          <div className="text-center py-6 text-muted-foreground">
            <div className="text-4xl mb-2">👥</div>
            <p>No team members yet</p>
            <p className="text-sm">Invite your first team member!</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {teamMembers.map((member) => (
              <div key={member.id} className="flex items-center gap-3 p-2 rounded border">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>{member.name.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{member.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{member.email}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge variant={member.status === "active" ? "default" : "secondary"}>{member.status}</Badge>
                  <span className="text-xs text-muted-foreground">{member.role}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

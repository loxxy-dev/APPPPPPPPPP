import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { BarChart3 } from "lucide-react"

export function UsageCard() {
  // This would typically come from your database/API
  const usage = {
    projects: { current: 8, limit: 10 },
    storage: { current: 6.5, limit: 10 },
    apiCalls: { current: 1250, limit: 5000 },
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-2">
          <BarChart3 className="h-5 w-5" />
          <CardTitle>Usage</CardTitle>
        </div>
        <CardDescription>Your current usage this month</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span>Projects</span>
            <span>
              {usage.projects.current}/{usage.projects.limit}
            </span>
          </div>
          <Progress value={(usage.projects.current / usage.projects.limit) * 100} />
        </div>
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span>Storage</span>
            <span>
              {usage.storage.current}GB/{usage.storage.limit}GB
            </span>
          </div>
          <Progress value={(usage.storage.current / usage.storage.limit) * 100} />
        </div>
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span>API Calls</span>
            <span>
              {usage.apiCalls.current.toLocaleString()}/{usage.apiCalls.limit.toLocaleString()}
            </span>
          </div>
          <Progress value={(usage.apiCalls.current / usage.apiCalls.limit) * 100} />
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Crown, Loader2, Shield } from "lucide-react"
import { isEmailRegistered } from "@/lib/storage"

export default function LoginPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [loginError, setLoginError] = useState("")
  const [adminError, setAdminError] = useState("")
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  })
  const [adminData, setAdminData] = useState({
    username: "",
    password: "",
  })
  const router = useRouter()

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))

    // Clear error when user types
    if (name === "email" || name === "password") {
      setLoginError("")
    }
  }

  const handleAdminInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setAdminData((prev) => ({
      ...prev,
      [name]: value,
    }))

    // Clear error when admin types
    setAdminError("")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setLoginError("")

    try {
      // Check if email is registered
      if (!isEmailRegistered(formData.email)) {
        setLoginError("Email not found. Please sign up first.")
        setIsLoading(false)
        return
      }

      // Simulate login process
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Set authentication cookies (check if user had a subscription)
      const existingPlan = localStorage.getItem(`plan_${formData.email}`) || null

      document.cookie = "user_email=" + formData.email + "; path=/; max-age=2592000"
      document.cookie = "user_authenticated=true; path=/; max-age=2592000"

      if (existingPlan) {
        document.cookie = "subscription_active=true; path=/; max-age=2592000"
        document.cookie = `subscription_plan=${existingPlan}; path=/; max-age=2592000`
      }

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      console.error("Login error:", error)
      setLoginError("Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setAdminError("")

    try {
      // Check admin credentials
      if (adminData.username !== "admin" || adminData.password !== "admin123") {
        setAdminError("Invalid admin credentials.")
        setIsLoading(false)
        return
      }

      // Simulate admin login process
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Set admin authentication cookies
      document.cookie = "user_email=admin@premiumapp.com; path=/; max-age=2592000"
      document.cookie = "user_authenticated=true; path=/; max-age=2592000"
      document.cookie = "user_role=admin; path=/; max-age=2592000"
      document.cookie = "subscription_active=true; path=/; max-age=2592000"
      document.cookie = "subscription_plan=Enterprise; path=/; max-age=2592000"

      // Redirect to dashboard
      router.push("/dashboard")
    } catch (error) {
      console.error("Admin login error:", error)
      setAdminError("Admin login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl w-full space-y-8">
        {/* Logo */}
        <div className="text-center">
          <Link href="/" className="inline-flex items-center space-x-2">
            <Crown className="h-8 w-8" />
            <span className="text-2xl font-bold">PremiumApp</span>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Regular User Login */}
          <Card>
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl text-center">Sign in to your account</CardTitle>
              <CardDescription className="text-center">
                Enter your email and password to access your account
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={handleInputChange}
                    disabled={isLoading}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={handleInputChange}
                    disabled={isLoading}
                  />
                </div>

                {loginError && <div className="text-sm text-red-500 text-center">{loginError}</div>}

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="rememberMe"
                      name="rememberMe"
                      type="checkbox"
                      className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                      checked={formData.rememberMe}
                      onChange={handleInputChange}
                      disabled={isLoading}
                    />
                    <label htmlFor="rememberMe" className="ml-2 block text-sm text-gray-900 dark:text-gray-100">
                      Remember me
                    </label>
                  </div>
                  <div className="text-sm">
                    <Link href="/forgot-password" className="font-medium text-primary hover:text-primary/80">
                      Forgot your password?
                    </Link>
                  </div>
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Signing in...
                    </>
                  ) : (
                    "Sign in"
                  )}
                </Button>
              </form>

              {/* Sign Up Link */}
              <div className="text-center">
                <span className="text-sm text-muted-foreground">
                  Don't have an account?{" "}
                  <Link href="/signup" className="font-medium text-primary hover:text-primary/80">
                    Sign up
                  </Link>
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Admin Login */}
          <Card className="border-orange-200 dark:border-orange-800">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl text-center flex items-center justify-center gap-2">
                <Shield className="h-6 w-6 text-orange-500" />
                ADMIN LOGIN
              </CardTitle>
              <CardDescription className="text-center">Administrator access only</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <form onSubmit={handleAdminSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin-username">Username</Label>
                  <Input
                    id="admin-username"
                    name="username"
                    type="text"
                    required
                    placeholder="Enter admin username"
                    value={adminData.username}
                    onChange={handleAdminInputChange}
                    disabled={isLoading}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-password">Password</Label>
                  <Input
                    id="admin-password"
                    name="password"
                    type="password"
                    required
                    placeholder="Enter admin password"
                    value={adminData.password}
                    onChange={handleAdminInputChange}
                    disabled={isLoading}
                  />
                </div>

                {adminError && <div className="text-sm text-red-500 text-center">{adminError}</div>}

                <Button type="submit" className="w-full bg-orange-500 hover:bg-orange-600" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Signing in...
                    </>
                  ) : (
                    <>
                      <Shield className="mr-2 h-4 w-4" />
                      Admin Sign in
                    </>
                  )}
                </Button>
              </form>

              {/* Admin Info */}
              <div className="text-center">
                <div className="text-xs text-muted-foreground bg-orange-50 dark:bg-orange-950 p-2 rounded">
                  Admin credentials required for system access
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Back to Home */}
        <div className="text-center">
          <Link href="/" className="text-sm text-muted-foreground hover:text-foreground">
            ← Back to home
          </Link>
        </div>
      </div>
    </div>
  )
}

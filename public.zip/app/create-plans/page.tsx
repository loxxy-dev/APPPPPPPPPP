import { Header } from "@/components/header"
import { PlanCreationGuide } from "@/components/plan-creation-guide"
import { Footer } from "@/components/footer"

export const metadata = {
  title: "Create PayPal Plans - Premium Subscription Service",
  description: "Set up your PayPal subscription plans",
}

export default function CreatePlansPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <div className="container py-8">
          <h1 className="text-3xl font-bold mb-6">PayPal Setup Guide</h1>

          <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-6 mb-8">
            <h2 className="text-xl font-semibold text-blue-800 dark:text-blue-200 mb-4">🚀 Quick Setup</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-blue-800 dark:text-blue-200">1. Get PayPal Credentials</h3>
                <p className="text-blue-700 dark:text-blue-300 text-sm">
                  Sign up for a PayPal Developer account and create an application to get your Client ID.
                </p>
              </div>

              <div>
                <h3 className="font-medium text-blue-800 dark:text-blue-200">2. Set Environment Variable</h3>
                <p className="text-blue-700 dark:text-blue-300 text-sm">
                  Add your PayPal Client ID to your environment variables:
                </p>
                <code className="block bg-blue-100 dark:bg-blue-900 p-2 rounded mt-2 text-sm">
                  NEXT_PUBLIC_PAYPAL_CLIENT_ID=your_actual_client_id_here
                </code>
              </div>

              <div>
                <h3 className="font-medium text-blue-800 dark:text-blue-200">3. Create Subscription Plans</h3>
                <p className="text-blue-700 dark:text-blue-300 text-sm">
                  Use the PayPal Developer Dashboard to create subscription plans for each pricing tier.
                </p>
              </div>
            </div>

            <div className="mt-6 p-4 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
              <p className="text-yellow-800 dark:text-yellow-200 text-sm">
                <strong>Demo Mode:</strong> Until you configure real PayPal credentials, the website will run in demo
                mode where payments are simulated. This allows you to test the full user experience without real
                transactions.
              </p>
            </div>
          </div>
        </div>
        <PlanCreationGuide />
      </main>
      <Footer />
    </div>
  )
}

"use client"

import type React from "react"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Crown, Users, CheckCircle } from "lucide-react"
import { processInvite } from "@/lib/storage"

export default function InvitePage() {
  const params = useParams()
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [isJoining, setIsJoining] = useState(false)
  const [success, setSuccess] = useState(false)
  const inviteCode = params.code as string

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return

    setIsJoining(true)

    try {
      // Simulate processing invite
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const success = processInvite(inviteCode, email)
      if (success) {
        setSuccess(true)
        // Redirect to signup/login after 3 seconds
        setTimeout(() => {
          router.push("/signup?invited=true")
        }, 3000)
      } else {
        alert("This email is already part of the team or the invite is invalid.")
      }
    } catch (error) {
      console.error("Error joining team:", error)
      alert("Failed to join team. Please try again.")
    } finally {
      setIsJoining(false)
    }
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <Card className="border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950">
            <CardHeader className="text-center">
              <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <CardTitle className="text-green-800 dark:text-green-200">Successfully Joined!</CardTitle>
              <CardDescription className="text-green-700 dark:text-green-300">
                You've been added to the team. Redirecting you to create your account...
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        {/* Logo */}
        <div className="text-center">
          <Link href="/" className="inline-flex items-center space-x-2">
            <Crown className="h-8 w-8" />
            <span className="text-2xl font-bold">PremiumApp</span>
          </Link>
        </div>

        {/* Invite Form */}
        <Card>
          <CardHeader className="space-y-1 text-center">
            <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <CardTitle className="text-2xl">You're Invited!</CardTitle>
            <CardDescription>
              You've been invited to join a team on PremiumApp. Enter your email to accept the invitation.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleJoin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isJoining}
                />
              </div>
              <Button type="submit" className="w-full" disabled={isJoining}>
                {isJoining ? "Joining Team..." : "Join Team"}
              </Button>
            </form>

            <div className="text-center text-sm text-muted-foreground">
              <p>
                Already have an account?{" "}
                <Link href="/login" className="font-medium text-primary hover:text-primary/80">
                  Sign in instead
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Back to Home */}
        <div className="text-center">
          <Link href="/" className="text-sm text-muted-foreground hover:text-foreground">
            ← Back to home
          </Link>
        </div>
      </div>
    </div>
  )
}

"use client"

export function SetupNotice() {
  // Return null to not display anything
  return null
}

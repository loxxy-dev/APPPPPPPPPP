"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { TaskCard } from "@/components/task-card"
import { NotesCard } from "@/components/notes-card"
import { CalendarCard } from "@/components/calendar-card"
import { TimeTrackingCard } from "@/components/time-tracking-card"
import { AnalyticsCard } from "@/components/analytics-card"
import { ProjectsCard } from "@/components/projects-card"
import { TeamCard } from "@/components/team-card"
import { SubscriptionCard } from "@/components/subscription-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Clock, CheckCircle, FileText, CalendarIcon, Sparkles, AlertTriangle } from "lucide-react"
import { getUserData, getUserEmail, getUserPlan } from "@/lib/storage"

function hasActiveSubscription(): boolean {
  if (typeof window === "undefined") return false
  return document.cookie.includes("subscription_active=true")
}

export default function DashboardPage() {
  const searchParams = useSearchParams()
  const [showWelcome, setShowWelcome] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [showNoPlan, setShowNoPlan] = useState(false)
  const [planName, setPlanName] = useState<string | null>(null)
  const [orderId, setOrderId] = useState<string | null>(null)
  const [userName, setUserName] = useState<string | null>(null)
  const [userData, setUserData] = useState<any>(null)
  const [hasSubscription, setHasSubscription] = useState(false)

  useEffect(() => {
    // Check subscription status
    const subscriptionActive = hasActiveSubscription()
    setHasSubscription(subscriptionActive)

    // Get user data
    const data = getUserData()
    setUserData(data)

    // Get user email and plan
    const email = getUserEmail()
    const plan = getUserPlan()
    setUserName(email)
    setPlanName(plan)

    // Check for welcome message (from signup/login)
    if (searchParams.get("welcome") === "true") {
      setShowWelcome(true)
      // Hide welcome message after 8 seconds
      setTimeout(() => setShowWelcome(false), 8000)
    }

    // Check for subscription success (from PayPal)
    if (searchParams.get("subscription") === "success") {
      setShowSuccess(true)
      setPlanName(searchParams.get("plan"))
      setOrderId(searchParams.get("id"))
      // Hide success message after 5 seconds
      setTimeout(() => setShowSuccess(false), 5000)
    }

    // Check for no plan message
    if (searchParams.get("no_plan") === "true") {
      setShowNoPlan(true)
      setTimeout(() => setShowNoPlan(false), 5000)
    }
  }, [searchParams])

  if (!userData) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading dashboard...</p>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  // Stats data
  const completedTasks = userData.tasks.filter((task: any) => task.completed).length
  const totalTasks = userData.tasks.length
  const hoursTracked = Math.round((userData.timeTracking.totalTime / 3600) * 10) / 10
  const upcomingEvents = 0 // Reset to 0

  const stats = [
    {
      title: "Tasks Completed",
      value: completedTasks.toString(),
      change: "+0",
      icon: CheckCircle,
    },
    {
      title: "Hours Tracked",
      value: hoursTracked.toString(),
      change: "+0",
      icon: Clock,
    },
    {
      title: "Notes Created",
      value: userData.notes ? "1" : "0",
      change: "+0",
      icon: FileText,
    },
    {
      title: "Upcoming Events",
      value: upcomingEvents.toString(),
      change: "0",
      icon: CalendarIcon,
    },
  ]

  return (
    <DashboardLayout>
      {/* Welcome Message for New Users */}
      {showWelcome && (
        <Card className="mb-6 border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <Sparkles className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-blue-800 dark:text-blue-200">Welcome to PremiumApp, {userName}! 🎉</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-blue-700 dark:text-blue-300">
              Your account has been created successfully! To access all features, please choose a subscription plan.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Subscription Success Message */}
      {showSuccess && (
        <Card className="mb-6 border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <CardTitle className="text-green-800 dark:text-green-200">Payment Successful!</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-green-700 dark:text-green-300">
              Thank you for subscribing to the {planName} plan! Your account has been upgraded and you now have access
              to all premium features.
              {orderId && <span className="block mt-2 font-mono text-xs">Order ID: {orderId}</span>}
            </p>
          </CardContent>
        </Card>
      )}

      {/* No Plan Warning */}
      {showNoPlan && (
        <Card className="mb-6 border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <CardTitle className="text-orange-800 dark:text-orange-200">Plan Required</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-orange-700 dark:text-orange-300">
              You need an active subscription to access that feature. Please choose a plan to continue.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Subscription Status */}
      <div className="mb-6">
        <SubscriptionCard planName={planName} />
      </div>

      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground mt-1">
                <span
                  className={stat.change.startsWith("+") ? "text-green-500" : stat.change === "0" ? "" : "text-red-500"}
                >
                  {stat.change}
                </span>{" "}
                from last week
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="space-y-6">
          <TaskCard />
          <ProjectsCard />
        </div>

        <div className="space-y-6">
          <TimeTrackingCard />
          <NotesCard />
        </div>

        <div className="space-y-6">
          <CalendarCard />
          <TeamCard />
        </div>
      </div>

      {/* Analytics */}
      <div className="mt-6">
        <AnalyticsCard />
      </div>
    </DashboardLayout>
  )
}

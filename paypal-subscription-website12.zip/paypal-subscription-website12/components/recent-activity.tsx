import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity, CreditCard, User, Settings } from "lucide-react"

const activities = [
  {
    icon: CreditCard,
    title: "Payment processed",
    description: "Monthly subscription payment of $19.99",
    time: "2 hours ago",
    type: "payment",
  },
  {
    icon: User,
    title: "Profile updated",
    description: "Changed email address and notification preferences",
    time: "1 day ago",
    type: "profile",
  },
  {
    icon: Settings,
    title: "Plan upgraded",
    description: "Upgraded from Basic to Pro plan",
    time: "3 days ago",
    type: "subscription",
  },
  {
    icon: Activity,
    title: "API limit reached",
    description: "Reached 80% of monthly API call limit",
    time: "5 days ago",
    type: "usage",
  },
]

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>Your recent account activity and updates</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div key={index} className="flex items-start space-x-4">
              <div className="rounded-full bg-muted p-2">
                <activity.icon className="h-4 w-4" />
              </div>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium">{activity.title}</p>
                <p className="text-sm text-muted-foreground">{activity.description}</p>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
              <Badge variant="outline" className="text-xs">
                {activity.type}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Plus, Briefcase, Calendar, TrendingUp, X } from "lucide-react"
import { getUserData, saveUserData, type Project } from "@/lib/storage"

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [newProject, setNewProject] = useState({
    name: "",
    dueDate: "",
    status: "Not Started",
  })

  useEffect(() => {
    const userData = getUserData()
    setProjects(userData.projects)
  }, [])

  const addProject = () => {
    if (newProject.name.trim()) {
      const project: Project = {
        name: newProject.name,
        progress: 0,
        status: newProject.status,
        dueDate: newProject.dueDate,
      }
      const updatedProjects = [...projects, project]
      setProjects(updatedProjects)
      saveUserData({ projects: updatedProjects })
      setNewProject({ name: "", dueDate: "", status: "Not Started" })
      setShowAddForm(false)
    }
  }

  const updateProjectProgress = (index: number, progress: number) => {
    const updatedProjects = projects.map((project, i) => {
      if (i === index) {
        let status = "Not Started"
        if (progress > 0 && progress < 100) status = "In Progress"
        if (progress === 100) status = "Completed"
        return { ...project, progress, status }
      }
      return project
    })
    setProjects(updatedProjects)
    saveUserData({ projects: updatedProjects })
  }

  const deleteProject = (index: number) => {
    const updatedProjects = projects.filter((_, i) => i !== index)
    setProjects(updatedProjects)
    saveUserData({ projects: updatedProjects })
  }

  const completedCount = projects.filter((p) => p.status === "Completed").length
  const inProgressCount = projects.filter((p) => p.status === "In Progress").length
  const averageProgress =
    projects.length > 0 ? Math.round(projects.reduce((sum, p) => sum + p.progress, 0) / projects.length) : 0

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Projects</h1>
          <p className="text-muted-foreground">Manage your projects and track progress</p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Briefcase className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium">Total Projects</p>
                  <p className="text-2xl font-bold">{projects.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm font-medium">Completed</p>
                  <p className="text-2xl font-bold">{completedCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Calendar className="h-5 w-5 text-purple-500" />
                <div>
                  <p className="text-sm font-medium">Avg Progress</p>
                  <p className="text-2xl font-bold">{averageProgress}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Add Project */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Projects</CardTitle>
              <Button onClick={() => setShowAddForm(true)} disabled={showAddForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add Project
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {showAddForm && (
              <div className="p-4 border rounded-lg space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="projectName">Project Name</Label>
                    <Input
                      id="projectName"
                      value={newProject.name}
                      onChange={(e) => setNewProject({ ...newProject, name: e.target.value })}
                      placeholder="Enter project name..."
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dueDate">Due Date</Label>
                    <Input
                      id="dueDate"
                      type="date"
                      value={newProject.dueDate}
                      onChange={(e) => setNewProject({ ...newProject, dueDate: e.target.value })}
                    />
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button onClick={addProject}>Add Project</Button>
                  <Button variant="outline" onClick={() => setShowAddForm(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {/* Projects List */}
            <div className="space-y-4">
              {projects.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Briefcase className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No projects yet. Add one to get started!</p>
                </div>
              ) : (
                projects.map((project, index) => (
                  <div key={index} className="p-4 border rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">{project.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          Due: {project.dueDate ? new Date(project.dueDate).toLocaleDateString() : "No due date"}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          variant={
                            project.status === "Completed"
                              ? "default"
                              : project.status === "In Progress"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {project.status}
                        </Badge>
                        <Button variant="ghost" size="sm" onClick={() => deleteProject(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Progress</span>
                        <span>{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                      <div className="flex space-x-2">
                        {[0, 25, 50, 75, 100].map((value) => (
                          <Button
                            key={value}
                            variant={project.progress === value ? "default" : "outline"}
                            size="sm"
                            onClick={() => updateProjectProgress(index, value)}
                          >
                            {value}%
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

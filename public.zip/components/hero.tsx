import { Button } from "@/components/ui/button"
import { ArrowRight, Star, Shield, Zap } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section className="container flex flex-col items-center justify-center space-y-8 py-24 md:py-32">
      <div className="flex items-center space-x-2 rounded-full border border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950 px-4 py-2 text-sm">
        <Star className="h-4 w-4 fill-current text-green-600" />
        <span className="text-green-700 dark:text-green-300">Trusted by 10,000+ users worldwide</span>
      </div>

      <div className="max-w-[980px] text-center">
        <h1 className="text-4xl font-bold leading-tight tracking-tighter md:text-6xl lg:leading-[1.1]">
          Unlock Premium Features with{" "}
          <span className="bg-gradient-to-r from-purple-600 via-blue-600 to-emerald-600 bg-clip-text text-transparent">
            Our Subscription
          </span>
        </h1>
        <p className="max-w-[750px] text-lg text-muted-foreground sm:text-xl mx-auto mt-6">
          Get access to advanced features, priority support, and exclusive content. Choose the plan that works best for
          you and start your journey today.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-center">
        <Button
          size="lg"
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold px-8 py-3 rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
          asChild
        >
          <Link href="#pricing">
            Get Started <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </Button>
        <Button
          variant="outline"
          size="lg"
          className="border-2 hover:bg-gray-50 dark:hover:bg-gray-900 px-8 py-3"
          asChild
        >
          <Link href="#features">Learn More</Link>
        </Button>
      </div>

      <div className="flex items-center space-x-8 mt-8">
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Shield className="h-4 w-4 text-green-600" />
          <span>Secure payments</span>
        </div>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Zap className="h-4 w-4 text-blue-600" />
          <span>Instant activation</span>
        </div>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Star className="h-4 w-4 text-yellow-600" />
          <span>14-day free trial</span>
        </div>
      </div>
    </section>
  )
}

"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CreditCard, AlertCircle } from "lucide-react"
import { getUserPlan } from "@/lib/storage"
import { toast } from "@/components/ui/use-toast"

export function SubscriptionCard({ planName }: { planName: string | null }) {
  const router = useRouter()
  const [isUpdating, setIsUpdating] = useState(false)

  // Get the current plan from storage if not provided
  const currentPlan = planName || getUserPlan() || "No Active Plan"

  // Format the plan name for display
  const formattedPlanName =
    currentPlan === "basic"
      ? "Basic"
      : currentPlan === "pro"
        ? "Professional"
        : currentPlan === "enterprise"
          ? "Enterprise"
          : "No Active Plan"

  // Determine if user has an active plan
  const hasActivePlan = currentPlan !== "No Active Plan" && currentPlan !== null

  // Handle update payment method
  const handleUpdatePayment = () => {
    setIsUpdating(true)

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Payment Update",
        description: "This would open a payment method update modal in production.",
      })
      setIsUpdating(false)
    }, 1000)
  }

  // Handle change plan
  const handleChangePlan = () => {
    // Scroll to pricing section or navigate to pricing page
    router.push("/#pricing")
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Subscription</CardTitle>
            <CardDescription>Manage your subscription plan</CardDescription>
          </div>
          <Badge variant={hasActivePlan ? "default" : "outline"} className="ml-2">
            {hasActivePlan ? "Active" : "Inactive"}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Current Plan</p>
              <p className="text-2xl font-bold">{formattedPlanName}</p>
            </div>
            {hasActivePlan && (
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Next billing date</p>
                <p className="font-medium">{new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}</p>
              </div>
            )}
          </div>

          {!hasActivePlan && (
            <div className="flex items-center p-3 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-md">
              <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400 mr-2 flex-shrink-0" />
              <p className="text-sm text-amber-800 dark:text-amber-300">
                You don't have an active subscription. Choose a plan to access all features.
              </p>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-2">
            {hasActivePlan && (
              <Button variant="outline" className="flex-1" onClick={handleUpdatePayment} disabled={isUpdating}>
                <CreditCard className="h-4 w-4 mr-2" />
                {isUpdating ? "Processing..." : "Update Payment"}
              </Button>
            )}
            <Button className="flex-1" onClick={handleChangePlan}>
              {hasActivePlan ? "Change Plan" : "Choose a Plan"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { PlanRequiredMessage } from "@/components/plan-required-message"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, X, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { getUserData, saveUserData, type Task } from "@/lib/storage"

function hasActiveSubscription(): boolean {
  if (typeof window === "undefined") return false
  return document.cookie.includes("subscription_active=true")
}

export default function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTask, setNewTask] = useState("")
  const [isAdding, setIsAdding] = useState(false)
  const [filter, setFilter] = useState<"all" | "active" | "completed">("all")

  useEffect(() => {
    if (hasActiveSubscription()) {
      const userData = getUserData()
      setTasks(userData.tasks)
    }
  }, [])

  if (!hasActiveSubscription()) {
    return (
      <DashboardLayout>
        <PlanRequiredMessage />
      </DashboardLayout>
    )
  }

  const addTask = () => {
    if (newTask.trim()) {
      const task: Task = {
        id: Date.now().toString(),
        text: newTask,
        completed: false,
        createdAt: new Date().toISOString(),
      }
      const updatedTasks = [...tasks, task]
      setTasks(updatedTasks)
      saveUserData({ tasks: updatedTasks })
      setNewTask("")
      setIsAdding(false)
    }
  }

  const toggleTask = (id: string) => {
    const updatedTasks = tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task))
    setTasks(updatedTasks)
    saveUserData({ tasks: updatedTasks })
  }

  const deleteTask = (id: string) => {
    const updatedTasks = tasks.filter((task) => task.id !== id)
    setTasks(updatedTasks)
    saveUserData({ tasks: updatedTasks })
  }

  const filteredTasks = tasks.filter((task) => {
    if (filter === "active") return !task.completed
    if (filter === "completed") return task.completed
    return true
  })

  const completedCount = tasks.filter((task) => task.completed).length
  const activeCount = tasks.filter((task) => !task.completed).length

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Tasks</h1>
          <p className="text-muted-foreground">Manage your tasks and stay organized</p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm font-medium">Completed</p>
                  <p className="text-2xl font-bold">{completedCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium">Active</p>
                  <p className="text-2xl font-bold">{activeCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-orange-500" />
                <div>
                  <p className="text-sm font-medium">Total</p>
                  <p className="text-2xl font-bold">{tasks.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Task Management */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Task List</CardTitle>
              <Button onClick={() => setIsAdding(true)} disabled={isAdding}>
                <Plus className="h-4 w-4 mr-2" />
                Add Task
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Add Task Form */}
            {isAdding && (
              <div className="flex items-center space-x-2 p-4 border rounded-lg">
                <Input
                  value={newTask}
                  onChange={(e) => setNewTask(e.target.value)}
                  placeholder="Enter task description..."
                  className="flex-1"
                  onKeyDown={(e) => e.key === "Enter" && addTask()}
                  autoFocus
                />
                <Button onClick={addTask}>Add</Button>
                <Button variant="ghost" onClick={() => setIsAdding(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}

            {/* Filter Buttons */}
            <div className="flex space-x-2">
              <Button variant={filter === "all" ? "default" : "outline"} size="sm" onClick={() => setFilter("all")}>
                All ({tasks.length})
              </Button>
              <Button
                variant={filter === "active" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("active")}
              >
                Active ({activeCount})
              </Button>
              <Button
                variant={filter === "completed" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("completed")}
              >
                Completed ({completedCount})
              </Button>
            </div>

            {/* Task List */}
            <div className="space-y-2">
              {filteredTasks.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {filter === "all" ? "No tasks yet. Add one to get started!" : `No ${filter} tasks.`}
                </div>
              ) : (
                filteredTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50"
                  >
                    <div className="flex items-center space-x-3">
                      <Checkbox
                        id={`task-${task.id}`}
                        checked={task.completed}
                        onCheckedChange={() => toggleTask(task.id)}
                      />
                      <div>
                        <label
                          htmlFor={`task-${task.id}`}
                          className={`text-sm cursor-pointer ${
                            task.completed ? "line-through text-muted-foreground" : ""
                          }`}
                        >
                          {task.text}
                        </label>
                        <p className="text-xs text-muted-foreground">
                          Created {new Date(task.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={task.completed ? "secondary" : "default"}>
                        {task.completed ? "Completed" : "Active"}
                      </Badge>
                      <Button variant="ghost" size="sm" onClick={() => deleteTask(task.id)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

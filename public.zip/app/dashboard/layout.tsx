import type { ReactNode } from "react"
import { redirect } from "next/navigation"
import { cookies } from "next/headers"
import { DashboardLayout } from "@/components/dashboard-layout"
import { PlanRequiredMessage } from "@/components/plan-required-message"

export default async function DashboardRootLayout({
  children,
}: {
  children: ReactNode
}) {
  // Check if user is authenticated
  const cookieStore = await cookies()
  const isAuthenticated = cookieStore.has("user_authenticated")
  const hasSubscription = cookieStore.has("subscription_active")
  const isMainDashboard = true // Main dashboard is always accessible

  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    redirect("/login")
  }

  return <DashboardLayout>{hasSubscription || isMainDashboard ? children : <PlanRequiredMessage />}</DashboardLayout>
}

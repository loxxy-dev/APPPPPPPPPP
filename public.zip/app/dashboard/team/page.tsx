"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Copy, Plus, Users, UserPlus, LinkIcon, Check } from "lucide-react"
import { getUserData, saveUserData, generateInviteLink, type TeamMember } from "@/lib/storage"

export default function TeamPage() {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([])
  const [inviteLink, setInviteLink] = useState("")
  const [showInviteForm, setShowInviteForm] = useState(false)
  const [newMemberEmail, setNewMemberEmail] = useState("")
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const userData = getUserData()
    setTeamMembers(userData.teamMembers)
  }, [])

  const generateNewInviteLink = () => {
    const link = generateInviteLink()
    setInviteLink(link)
  }

  const copyInviteLink = () => {
    if (inviteLink) {
      navigator.clipboard.writeText(inviteLink)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const addTeamMember = () => {
    if (newMemberEmail.trim()) {
      const newMember: TeamMember = {
        id: Date.now().toString(),
        name: newMemberEmail.split("@")[0],
        email: newMemberEmail,
        role: "Team Member",
        status: "offline",
        joinedAt: new Date().toISOString(),
      }

      // Check if member already exists
      const exists = teamMembers.some((member) => member.email === newMemberEmail)
      if (exists) {
        alert("This email is already part of your team!")
        return
      }

      const updatedMembers = [...teamMembers, newMember]
      setTeamMembers(updatedMembers)
      saveUserData({ teamMembers: updatedMembers })
      setNewMemberEmail("")
      setShowInviteForm(false)
    }
  }

  const removeTeamMember = (id: string) => {
    if (confirm("Are you sure you want to remove this team member?")) {
      const updatedMembers = teamMembers.filter((member) => member.id !== id)
      setTeamMembers(updatedMembers)
      saveUserData({ teamMembers: updatedMembers })
    }
  }

  const updateMemberStatus = (id: string, status: "online" | "offline" | "busy") => {
    const updatedMembers = teamMembers.map((member) => (member.id === id ? { ...member, status } : member))
    setTeamMembers(updatedMembers)
    saveUserData({ teamMembers: updatedMembers })
  }

  const onlineCount = teamMembers.filter((member) => member.status === "online").length
  const totalCount = teamMembers.length

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Team</h1>
          <p className="text-muted-foreground">Manage your team members and collaboration</p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium">Total Members</p>
                  <p className="text-2xl font-bold">{totalCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <UserPlus className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm font-medium">Online Now</p>
                  <p className="text-2xl font-bold">{onlineCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <LinkIcon className="h-5 w-5 text-purple-500" />
                <div>
                  <p className="text-sm font-medium">Invite Link</p>
                  <Button variant="outline" size="sm" onClick={generateNewInviteLink}>
                    Generate
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Invite Section */}
        <Card>
          <CardHeader>
            <CardTitle>Invite Team Members</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Invite Link */}
            {inviteLink && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Share this invite link:</label>
                <div className="flex space-x-2">
                  <Input value={inviteLink} readOnly className="flex-1" />
                  <Button onClick={copyInviteLink} variant="outline">
                    {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    {copied ? "Copied!" : "Copy"}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Anyone with this link can join your team. Share it securely.
                </p>
              </div>
            )}

            {/* Direct Invite */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Or invite directly by email:</label>
              {showInviteForm ? (
                <div className="flex space-x-2">
                  <Input
                    type="email"
                    placeholder="Enter email address..."
                    value={newMemberEmail}
                    onChange={(e) => setNewMemberEmail(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && addTeamMember()}
                    className="flex-1"
                  />
                  <Button onClick={addTeamMember}>Add</Button>
                  <Button variant="outline" onClick={() => setShowInviteForm(false)}>
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button onClick={() => setShowInviteForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Team Member
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Team Members List */}
        <Card>
          <CardHeader>
            <CardTitle>Team Members ({totalCount})</CardTitle>
          </CardHeader>
          <CardContent>
            {teamMembers.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No team members yet. Invite someone to get started!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {teamMembers.map((member) => (
                  <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={member.avatar || "/placeholder.svg"} alt={member.name} />
                        <AvatarFallback>
                          {member.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")
                            .toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{member.name}</div>
                        <div className="text-sm text-muted-foreground">{member.email}</div>
                        <div className="text-xs text-muted-foreground">
                          Joined {new Date(member.joinedAt).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge
                        variant={
                          member.status === "online" ? "default" : member.status === "busy" ? "destructive" : "outline"
                        }
                        className="cursor-pointer"
                        onClick={() => {
                          const statuses: Array<"online" | "offline" | "busy"> = ["online", "busy", "offline"]
                          const currentIndex = statuses.indexOf(member.status)
                          const nextStatus = statuses[(currentIndex + 1) % statuses.length]
                          updateMemberStatus(member.id, nextStatus)
                        }}
                      >
                        {member.status}
                      </Badge>
                      <Badge variant="outline">{member.role}</Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeTeamMember(member.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

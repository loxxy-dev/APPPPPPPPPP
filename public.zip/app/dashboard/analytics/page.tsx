"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { BarChart3, TrendingUp, Clock, CheckCircle } from "lucide-react"
import { getUserData } from "@/lib/storage"

export default function AnalyticsPage() {
  const [userData, setUserData] = useState<any>(null)

  useEffect(() => {
    const data = getUserData()
    setUserData(data)
  }, [])

  if (!userData) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="text-muted-foreground">Loading analytics...</p>
          </div>
        </div>
      </DashboardLayout>
    )
  }

  const completedTasks = userData.tasks.filter((task: any) => task.completed).length
  const totalTasks = userData.tasks.length
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0
  const hoursTracked = Math.round((userData.timeTracking.totalTime / 3600) * 10) / 10
  const completedProjects = userData.projects.filter((p: any) => p.status === "Completed").length

  // Generate weekly data based on user activity
  const weeklyData = [
    { name: "Mon", tasks: Math.floor(completedTasks * 0.15), hours: Math.floor(hoursTracked * 0.12) },
    { name: "Tue", tasks: Math.floor(completedTasks * 0.18), hours: Math.floor(hoursTracked * 0.16) },
    { name: "Wed", tasks: Math.floor(completedTasks * 0.14), hours: Math.floor(hoursTracked * 0.18) },
    { name: "Thu", tasks: Math.floor(completedTasks * 0.16), hours: Math.floor(hoursTracked * 0.15) },
    { name: "Fri", tasks: Math.floor(completedTasks * 0.2), hours: Math.floor(hoursTracked * 0.2) },
    { name: "Sat", tasks: Math.floor(completedTasks * 0.1), hours: Math.floor(hoursTracked * 0.12) },
    { name: "Sun", tasks: Math.floor(completedTasks * 0.07), hours: Math.floor(hoursTracked * 0.07) },
  ]

  const projectStatusData = [
    {
      name: "Completed",
      value: userData.projects.filter((p: any) => p.status === "Completed").length,
      color: "#10b981",
    },
    {
      name: "In Progress",
      value: userData.projects.filter((p: any) => p.status === "In Progress").length,
      color: "#3b82f6",
    },
    {
      name: "Not Started",
      value: userData.projects.filter((p: any) => p.status === "Not Started").length,
      color: "#6b7280",
    },
  ]

  const productivityScore = Math.round(
    (completionRate + (hoursTracked > 0 ? 80 : 0) + (completedProjects > 0 ? 90 : 0)) / 3,
  )

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Analytics</h1>
          <p className="text-muted-foreground">Insights into your productivity and performance</p>
        </div>

        {/* Key Metrics */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm font-medium">Task Completion</p>
                  <p className="text-2xl font-bold">{completionRate}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium">Hours Tracked</p>
                  <p className="text-2xl font-bold">{hoursTracked}h</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5 text-purple-500" />
                <div>
                  <p className="text-sm font-medium">Projects Done</p>
                  <p className="text-2xl font-bold">{completedProjects}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-orange-500" />
                <div>
                  <p className="text-sm font-medium">Productivity Score</p>
                  <p className="text-2xl font-bold">{productivityScore}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid gap-6 md:grid-cols-2">
          {/* Weekly Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Weekly Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weeklyData}>
                    <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--background)",
                        borderColor: "var(--border)",
                        borderRadius: "0.5rem",
                        fontSize: "0.75rem",
                      }}
                    />
                    <Bar dataKey="tasks" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="hours" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center mt-4 space-x-4">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[hsl(var(--chart-1))] mr-2"></div>
                  <span className="text-xs">Tasks Completed</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-[hsl(var(--chart-2))] mr-2"></div>
                  <span className="text-xs">Hours Worked</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Project Status */}
          <Card>
            <CardHeader>
              <CardTitle>Project Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={projectStatusData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {projectStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center mt-4 space-x-4">
                {projectStatusData.map((entry, index) => (
                  <div key={index} className="flex items-center">
                    <div className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: entry.color }}></div>
                    <span className="text-xs">
                      {entry.name} ({entry.value})
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Productivity Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Productivity Insights</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <h4 className="font-medium">Task Performance</h4>
                <p className="text-sm text-muted-foreground">
                  You've completed {completedTasks} out of {totalTasks} tasks ({completionRate}% completion rate).
                  {completionRate >= 80
                    ? " Excellent work!"
                    : completionRate >= 60
                      ? " Good progress!"
                      : " Keep pushing forward!"}
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">Time Management</h4>
                <p className="text-sm text-muted-foreground">
                  You've tracked {hoursTracked} hours of work time.
                  {hoursTracked >= 40
                    ? " Great dedication!"
                    : hoursTracked >= 20
                      ? " Good effort!"
                      : " Consider tracking more time to improve insights."}
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">Project Progress</h4>
                <p className="text-sm text-muted-foreground">
                  {completedProjects} projects completed out of {userData.projects.length} total.
                  {completedProjects > 0
                    ? " You're making great progress!"
                    : " Start completing projects to see better insights."}
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">Team Collaboration</h4>
                <p className="text-sm text-muted-foreground">
                  Your team has {userData.teamMembers.length} members.
                  {userData.teamMembers.length > 0
                    ? " Great teamwork!"
                    : " Consider inviting team members to collaborate."}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

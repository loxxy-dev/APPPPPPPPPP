import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Zap, Users, Crown, Headphones, Sparkles } from "lucide-react"

const features = [
  {
    icon: Crown,
    title: "Premium Access",
    description: "Unlock all premium features and content with your subscription.",
  },
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Experience blazing fast performance with our optimized infrastructure.",
  },
  {
    icon: Shield,
    title: "Secure & Private",
    description: "Your data is protected with enterprise-grade security measures.",
  },
  {
    icon: Users,
    title: "Team Collaboration",
    description: "Work together seamlessly with advanced collaboration tools.",
  },
  {
    icon: Headphones,
    title: "Priority Support",
    description: "Get help when you need it with our dedicated support team.",
  },
  {
    icon: Sparkles,
    title: "Regular Updates",
    description: "Enjoy new features and improvements delivered regularly.",
  },
]

export function Features() {
  return (
    <section id="features" className="container py-24">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Everything you need to succeed</h2>
        <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
          Our platform provides all the tools and features you need to take your work to the next level.
        </p>
      </div>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((feature, index) => (
          <Card key={index} className="relative overflow-hidden">
            <CardHeader>
              <feature.icon className="h-10 w-10 text-primary" />
              <CardTitle>{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>{feature.description}</CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}

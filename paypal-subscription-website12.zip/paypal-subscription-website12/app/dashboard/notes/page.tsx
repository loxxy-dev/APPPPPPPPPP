"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Save, FileText } from "lucide-react"
import { getUserData, saveUserData } from "@/lib/storage"

export default function NotesPage() {
  const [notes, setNotes] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [lastSaved, setLastSaved] = useState<Date | null>(null)

  useEffect(() => {
    const userData = getUserData()
    setNotes(userData.notes)
  }, [])

  const handleSave = () => {
    setIsSaving(true)
    saveUserData({ notes })
    setLastSaved(new Date())
    setTimeout(() => {
      setIsSaving(false)
    }, 800)
  }

  const handleNotesChange = (value: string) => {
    setNotes(value)
    // Auto-save after 2 seconds of inactivity
    const timeoutId = setTimeout(() => {
      saveUserData({ notes: value })
      setLastSaved(new Date())
    }, 2000)

    return () => clearTimeout(timeoutId)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Notes</h1>
          <p className="text-muted-foreground">Keep track of your thoughts and ideas</p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <FileText className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="text-sm font-medium">Characters</p>
                  <p className="text-2xl font-bold">{notes.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <FileText className="h-5 w-5 text-green-500" />
                <div>
                  <p className="text-sm font-medium">Words</p>
                  <p className="text-2xl font-bold">{notes.trim() ? notes.trim().split(/\s+/).length : 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <FileText className="h-5 w-5 text-purple-500" />
                <div>
                  <p className="text-sm font-medium">Lines</p>
                  <p className="text-2xl font-bold">{notes.split("\n").length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Notes Editor */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Your Notes</CardTitle>
              <div className="flex items-center space-x-2">
                {lastSaved && (
                  <span className="text-xs text-muted-foreground">Last saved: {lastSaved.toLocaleTimeString()}</span>
                )}
                <Button onClick={handleSave} disabled={isSaving}>
                  <Save className="h-4 w-4 mr-2" />
                  {isSaving ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Textarea
              value={notes}
              onChange={(e) => handleNotesChange(e.target.value)}
              placeholder="Start writing your notes here..."
              className="min-h-[400px] resize-none"
            />
            <div className="mt-4 text-xs text-muted-foreground">
              💡 Tip: Your notes are automatically saved as you type
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
